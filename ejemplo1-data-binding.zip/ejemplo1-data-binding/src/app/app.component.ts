import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  nombre: string = 'Anabel';
  apellido: string = "Vegas";

  deshabilitado: boolean = true;

  texto: string = '';

  constructor(){
    // Crear un temporizador que cuando transcurra 5 segundos,
    // habilitamos el boton
    setTimeout( () => {
      this.deshabilitado = false;
    }  , 5000);
  }

  mostrarSaludo(): void{
    alert("Bienvenido al curso de Angular");
  }

}
