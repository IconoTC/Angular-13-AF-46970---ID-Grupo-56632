import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cinco',
  templateUrl: './cinco.component.html',
  styleUrls: ['./cinco.component.css']
})
export class CincoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
