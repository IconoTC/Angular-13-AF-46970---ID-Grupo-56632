
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { MuseosComponent } from './components/museos/museos.component';
import { DetalleMuseoComponent } from './components/detalle-museo/detalle-museo.component';
import { HomeComponent } from './components/home/home.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { ErrorComponent } from './components/error/error.component';
import { EquipoComponent } from './components/equipo/equipo.component';
import { Routes, RouterModule } from '@angular/router';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { FormsModule } from '@angular/forms';

import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorIntl, MatPaginatorModule } from '@angular/material/paginator';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

import { AngularFireModule } from '@angular/fire/compat';
import { environment } from 'src/environments/environment';

// Crear el array de rutas
const misRutas: Routes = [
  {path: 'home', component: HomeComponent},
  {path: 'museos', component: MuseosComponent},
  {path: 'detalle/:codigo', component: DetalleMuseoComponent},
  {path: 'equipo', component: EquipoComponent},
  {path: '', redirectTo: 'home', pathMatch: 'full'}, // la ruta debe ser localhost:4200
  {path: '**', component: ErrorComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    MuseosComponent,
    DetalleMuseoComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    NavbarComponent,
    ErrorComponent,
    EquipoComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(misRutas),
    HttpClientModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (http: HttpClient) => {
          return new TranslateHttpLoader(http);
        },
        deps: [HttpClient]
      }
    }),
    BrowserAnimationsModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule,
    FormsModule,
    AngularFireModule.initializeApp(environment.firebase),
  ],
  providers: [MatPaginatorIntl],
  bootstrap: [AppComponent]
})
export class AppModule { }
