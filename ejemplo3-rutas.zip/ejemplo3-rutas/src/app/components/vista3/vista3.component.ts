import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-vista3',
  templateUrl: './vista3.component.html',
  styleUrls: ['./vista3.component.css']
})
export class Vista3Component {

  hotel: string = '';
  entrada: string = '';
  salida:  string = '';
  habitaciones: number = 0;

  constructor(private ruta: ActivatedRoute){

    // Recuperar el parametro REST
    // El nombre del parametro esta definido en la ruta app.module.ts  v3/:hotel
    console.log(this.ruta);
    this.hotel = this.ruta.snapshot.params['hotel'];

    // Recuperar los query params
    this.entrada = this.ruta.snapshot.queryParams['entrada'];
    this.salida = this.ruta.snapshot.queryParams['salida'];
    this.habitaciones = this.ruta.snapshot.queryParams['habitaciones'];
  }
}
