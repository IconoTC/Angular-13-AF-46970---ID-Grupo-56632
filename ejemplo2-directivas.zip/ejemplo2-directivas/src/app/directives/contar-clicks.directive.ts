import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appContarClicks]'
})
export class ContarClicksDirective {

  numeroClicks: number = 0;

  // Modificamos la propiedad CSS font-size
  @HostBinding('style.font-size')  // tambien funciona style.fontSize
  size: string = '';

  @HostBinding('style.opacity')
  opacidad: number = 0.1;

  constructor() { }


  // Quiero detectar cada vez que se hace click sobre un alumno
  @HostListener('click')
  procesarClick(): void{
    this.numeroClicks++;
    this.size = (20 + this.numeroClicks + "px");
    this.opacidad += 0.1;  // this.opacidad = this.opacidad + 0.1;
  }

}
