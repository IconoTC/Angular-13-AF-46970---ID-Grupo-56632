import { Component } from '@angular/core';
import { PokemonService } from './services/pokemon.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  pokemons: any[] = [];
  urlSiguiente: string = '';
  urlAnterior: string = '';
  deshabilitado: boolean = true;
  nombre: string = '';
  pokemon: any;

  constructor(private pokemonService: PokemonService){
    
    // Esto no se puede hacer
    // this.pokemons = pokemonService.getAll();

    // Me subscribo al Observable para estar atenta a recibir notificaciones
    pokemonService.getAll().subscribe( (datos) => {
      //console.log(datos);
      this.pokemons = datos.results;
      this.urlSiguiente = datos.next;
    } );
  }

  buscarPokemon(){
    this.pokemonService.buscarPokemon(this.nombre).subscribe( (item) => {
      console.log(item);
      this.pokemon = item;
    } );
  }

  adelante(){
    this.pokemonService.emitirPeticion(this.urlSiguiente).subscribe( (datos) => {
      //console.log(datos);
      this.pokemons = datos.results;
      this.urlSiguiente = datos.next;
      this.urlAnterior = datos.previous;
      this.deshabilitado = false;
    } );
  }

  atras(){
    this.pokemonService.emitirPeticion(this.urlAnterior).subscribe( (datos) => {
      //console.log(datos);
      this.pokemons = datos.results;
      this.urlSiguiente = datos.next;
      this.urlAnterior = datos.previous;
      if (this.urlAnterior == null){
        this.deshabilitado = true;
      }
    } );
  }

}
