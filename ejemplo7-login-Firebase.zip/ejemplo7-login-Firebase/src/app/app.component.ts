import { Component } from '@angular/core';
import { LoginService } from './services/login.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  registro: boolean = false;    // true -> registro, false -> login
  email: string = '';
  pw: string = '';
  confPw: string = '';
  estoyLogado: boolean = false;
  usuario: any = '';

  constructor(private loginService: LoginService){
    this.loginService.comprobar().subscribe((dato) => {
      console.log(dato?.email);
      this.usuario = dato?.email;
    });
  }

  logout(){
    this.loginService.logout()
      .then( () => {
        this.estoyLogado = false;
        this.email = '';
        this.pw = '';
      })
      .catch( (error) => {
        console.log(error)
      });
  }

  login(){
    this.loginService.login(this.email, this.pw)
      .then(() => {
        alert("Usuario logado");
        this.estoyLogado = true;
      })
      .catch((error) => {
        console.log(error);
        alert("Las credenciales no son correctas");
      } )
  }

  registrarse(){
    if (this.pw == this.confPw){
      this.loginService.registro(this.email, this.pw)
        .then(() => {
          alert("Usuario registrado");
        })
        .catch((error)=> {
          console.log(error);
        })
    } else {
      alert("Los pw no coinciden");
    }
  }

}
