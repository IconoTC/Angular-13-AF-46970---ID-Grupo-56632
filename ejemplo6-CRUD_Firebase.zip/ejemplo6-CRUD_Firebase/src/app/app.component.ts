import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AgendaService } from './service/agenda.service';
import { map } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  contactos: any;
  mostrar: boolean = false;
  id: string = '';

  contactoForm = new FormGroup({
    nombre: new FormControl('', Validators.minLength(3)),
    telefono: new FormControl('', 
      [Validators.required, Validators.pattern('[6-7]{1}[0-9]{8}')])
  });

  contactoForm2 = new FormGroup({
    nombre: new FormControl('', Validators.minLength(3)),
    telefono: new FormControl('', 
      [Validators.required, Validators.pattern('[6-7]{1}[0-9]{8}')])
  });

  constructor(private agendaService: AgendaService){
    this.agendaService.getAll().snapshotChanges().pipe(
      map(cambio => cambio.map(c => (
        {key: c.payload.key, ...c.payload.val()}
        )))
    ).subscribe(datos => {    
      this.contactos = datos;
      console.log(this.contactos);
    })
  }

  modificar(contacto: any){
    this.mostrar = true;
    this.id = contacto.key;
    this.contactoForm2.setValue({
      nombre: contacto.nombre,
      telefono: contacto.telefono
    });
  }

  guardar(){ 
    this.agendaService.modificar(this.id, this.contactoForm2.value)
      .then(() => {
        alert("Contacto modificado");
        this.mostrar = false;
      })
      .catch( (error) => {
        console.log(error);
      });
  }

  borrar(key: string){
    this.agendaService.eliminar(key)
      .then(() => {
        alert("Contacto eliminado");
      })
      .catch((error) => {
        console.log(error);
      } )
  }

  alta(){
    console.log(this.contactoForm.value);
    this.agendaService.crear(this.contactoForm.value).then(() => {
      alert("Contacto agregado correctamente");
      // limpiar el formulario
      this.contactoForm.reset();
    }, (error: any) => {
      console.log(error);
    })
  }
}
