import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AgendaService } from './service/agenda.service';
import { map } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  contactos: any;

  contactoForm = new FormGroup({
    nombre: new FormControl('', Validators.minLength(3)),
    telefono: new FormControl('', 
      [Validators.required, Validators.pattern('[6-7]{1}[0-9]{8}')])
  });

  constructor(private agendaService: AgendaService){
    this.agendaService.getAll().snapshotChanges().pipe(
      map(cambio => cambio.map(c => (
        {key: c.payload.key, ...c.payload.val()}
        )))
    ).subscribe(datos => {    
      this.contactos = datos;
      console.log(this.contactos);
    })
  }

  alta(){
    console.log(this.contactoForm.value);
    this.agendaService.crear(this.contactoForm.value).then(() => {
      alert("Contacto agregado correctamente");
      // limpiar el formulario
      this.contactoForm.reset();
    }, (error: any) => {
      console.log(error);
    })
  }
}
