import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList } from '@angular/fire/compat/database';

@Injectable({
  providedIn: 'root'
})
export class AgendaService {

  private db = '/agenda';
  agendaRef: AngularFireList<any>;

  constructor(private angularDB: AngularFireDatabase) {
    this.agendaRef = this.angularDB.list(this.db);
  }

  getAll(): AngularFireList<any>{
    return this.agendaRef;
  }

  crear(contacto: any): any{
    return this.agendaRef.push(contacto);
  }

  modificar(key: string, value: any): Promise<void>{
    return this.agendaRef.update(key, value);
  }

  eliminar(key: string): Promise<void>{
    return this.agendaRef.remove(key);
  }
}
