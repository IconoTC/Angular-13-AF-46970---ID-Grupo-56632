export const environment = {
    production: false,
    firebase: {
        apiKey: "AIzaSyAutLS3IxtEN6SugF9mKRRxafzXu5rSpBY",
        authDomain: "indra-anabel-b03ca.firebaseapp.com",
        databaseURL: "https://indra-anabel-b03ca-default-rtdb.europe-west1.firebasedatabase.app/",
        projectId: "indra-anabel-b03ca",
        storageBucket: "indra-anabel-b03ca.appspot.com",
        messagingSenderId: "795003557210",
        appId: "1:795003557210:web:ab2f46e224568f8e55cf63"
    }
};